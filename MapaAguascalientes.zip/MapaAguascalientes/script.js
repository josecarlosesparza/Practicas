// Inicializar el mapa centrado en Aguascalientes
var map = L.map('map').setView([21.88234, -102.28259], 13);

// Añadir capa de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
}).addTo(map);

// Crear un ícono personalizado para Aguascalientes
var iconAguascalientes = L.icon({
    iconUrl: 'imagenes/aguascalientes_centro.jpg',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38]
});

// Añadir un marcador en Aguascalientes capital
var marker = L.marker([21.88234, -102.28259], { icon: iconAguascalientes }).addTo(map);
marker.bindPopup("<b>¡Bienvenidos a Aguascalientes!</b><br>Capital del Estado.").openPopup();

// Crear un ícono personalizado para la Plaza de la Patria
var iconPlazaPatria = L.icon({
    iconUrl: 'imagenes/plaza-patria.jpg',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38]
});

// Marcador en la Plaza de la Patria
var plazaPatria = L.marker([21.88187, -102.29495], { icon: iconPlazaPatria }).addTo(map);
plazaPatria.bindPopup("<b>Plaza de la Patria</b><br>Corazón de Aguascalientes.");

// Crear un ícono personalizado para el Museo Nacional de la Muerte
var iconMuseoMuerte = L.icon({
    iconUrl: 'imagenes/museo_muerte.jpg',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38]
});

// Marcador en el Museo Nacional de la Muerte
var museoMuerte = L.marker([21.88417, -102.28878], { icon: iconMuseoMuerte }).addTo(map);
museoMuerte.bindPopup("<b>Museo Nacional de la Muerte</b><br>Un lugar único.");

// Ícono personalizado para Tres Centurias
var iconTresCenturias = L.icon({
    iconUrl: 'imagenes/tres-centurias.jpeg',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38]
});

// Marcador en Tres Centurias
var tresCenturias = L.marker([21.88473, -102.2811], { icon: iconTresCenturias }).addTo(map);
tresCenturias.bindPopup("<b>Tres Centurias</b><br>Un lugar emblemático en Aguascalientes.");

// Crear un ícono personalizado para la Isla San Marcos
var iconIslaSanMarcos = L.icon({
    iconUrl: 'imagenes/Isla-san-marcos-.jpeg',
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38]
});

// Marcador en la Isla San Marcos
var islaSanMarcos = L.marker([21.96137, -102.307], { icon: iconIslaSanMarcos }).addTo(map);
islaSanMarcos.bindPopup("<b>Isla San Marcos</b><br>Un hermoso espacio recreativo.");


// Polígono para resaltar el Centro Histórico
var centroHistorico = L.polygon([
    [21.8821, -102.2935],
    [21.8829, -102.2865],
    [21.8797, -102.2860],
    [21.8792, -102.2920]
]).addTo(map);
centroHistorico.bindPopup("<b>Centro Histórico de Aguascalientes</b><br>Una joya colonial.");

// Agregar capas para mostrar/ocultar marcadores y formas
var baseMaps = {
    "Mapa base": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
};

var overlayMaps = {
    "Lugares importantes": L.layerGroup([marker, plazaPatria, museoMuerte, tresCenturias]),
    "Feria de San Marcos": feriaSanMarcos,
    "Centro Histórico": centroHistorico
};

overlayMaps["Lugares importantes"].addLayer(islaSanMarcos);
L.control.layers(baseMaps, overlayMaps).addTo(map);
