// Cargar el framework Express y el módulo Path
const express = require('express');
const path = require('path');
// Crear una instancia de la aplicación de Express
const app = express();
// Middleware para servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));
// Ruta principal '/' que envía el archivo 'index.html' como respuesta
app.get('/', (req, res) => {
    // Enviar el archivo 'index.html' desde la carpeta 'public'
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// Definir el puerto, utilizando el puerto del entorno o 3000 como valor por defecto
const PORT = process.env.PORT || 3000;
// Iniciar el servidor y escuchar en el puerto especificado
app.listen(PORT, () => {
    // Mostrar mensaje en la consola cuando el servidor esté corriendo
    console.log('Servidor corriendo en http://localhost:${PORT}');
});